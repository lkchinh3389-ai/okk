# FF Test Overlay

Overlay ESP + bang dieu khien cho server rieng Free Fire 1.70.0 (moi truong test).

## Cau truc
- `app/` – app Android (package `com.test.overlay`)
- `frida/ff_test_hook.js` – script Frida (server TCP 127.0.0.1:27111)
- `.github/workflows/build.yml` – build APK bang GitHub Actions

## Build APK
1. Tao repo GitHub, day **toan bo noi dung** thu muc nay len nhanh `main` (file `.github` nam o goc repo).
2. Vao tab **Actions** → `Build Overlay APK` → **Run workflow** (hoac tu chay khi push).
3. Cho xong, tai artifact `ff-overlay-debug-apk` → giai nen ra `app-debug.apk` → cai len may.

Workflow tu cai Gradle 8.5, khong can `gradlew`.

## Dung
1. Mo app, cap quyen "hien thi tren ung dung khac", bam **Bat overlay**.
2. Chay game da gan Frida Gadget + `ff_test_hook.js`.
3. Cham bieu tuong ◎ noi tren man hinh de mo bang dieu khien (keo de di chuyen).

Mac dinh script dung entity gia (`useMock = true`) de kiem tra overlay.
Feed du lieu that bang `rpc.exports.setEntities([...])` (toa do chuan hoa 0..1).

## Ban dung offset that: frida/ff_real_hook.js
- Dung offset tu `com_dts_freefireth__x64__cs.txt` (GameFacade, Player, Camera, Transform).
- Tu kiem tra versionName phai bat dau bang `1.70` (REQUIRE_VERSION_PREFIX), khong khop thi khong hook.
- ESP: lay Player bang hook get_IsDieing / IsVisible / get_CurHP, doi sang toa do man hinh bang Camera.WorldToScreenPoint.
- Fly (len theo truc Y), TP (toi truoc theo huong camera), Pin (khoa vi tri), Aim (SetAimRotation) chi tac dong len local player.
- Debug: `rpc.exports.status()`, chinh `tune('headH', 1.8)`, `tune('renderScale', 0.75)`, `setScreen(w,h)`.

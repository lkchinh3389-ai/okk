'use strict';

// ff_test_hook.js - Frida test hook cho server rieng (Free Fire 1.70.0, moi truong test)
// Bridge: script mo server TCP 127.0.0.1:27111, app overlay (com.test.overlay) ket noi vao.

const LIB_IL2CPP = 'libil2cpp.so';
const HOST = '127.0.0.1';
const PORT = 27111;

// Dien RVA thu cong neu tim theo ten khong ra (0x0 = bo qua, tu tim bang il2cpp API)
const MANUAL_RVA = {
    get_HeadCollider: 0x0,
    get_main: 0x0,
    get_forward: 0x0,
    get_position_Injected: 0x0,
    set_position_Injected: 0x0,
    WorldToScreenPoint: 0x0,
};

const state = {
    espBox: true,
    espLine: true,
    espDist: true,
    espHp: true,
    espName: true,
    rgbMode: true,
    colorHex: '#FF3B30',
    headPin: false,
    aimEnabled: false,
    flyEnabled: false,
    flySpeed: 1.5,
    stepForward: 2.5,
    pinnedHeadPos: null,
    lastKnownHead: null,
    aimTarget: null,
    _pendingTp: false,
};

// Chi cho phep app overlay doi cac key nay qua lenh "cfg"
const CFG_WHITELIST = [
    'espBox', 'espLine', 'espDist', 'espHp', 'espName', 'rgbMode', 'colorHex',
    'headPin', 'aimEnabled', 'flyEnabled', 'flySpeed', 'stepForward',
];

let useMock = true;            // true: dung entity gia de test overlay
let externalEntities = [];     // du lieu that (feed qua rpc.setEntities)
let playerTransformPtr = null; // neu dat: tp/fly/pin chi ap dung cho Transform nay

function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

// ---------------------------------------------------------------- util
function bytesToStr(buf) {
    const u8 = new Uint8Array(buf);
    let s = '';
    for (let i = 0; i < u8.length; i++) s += String.fromCharCode(u8[i]);
    return s;
}

// JSON thuan ASCII (escape \uXXXX) -> khong can TextEncoder
function asciiBytes(obj) {
    const s = JSON.stringify(obj).replace(/[\u007f-\uffff]/g, function (c) {
        return '\\u' + ('0000' + c.charCodeAt(0).toString(16)).slice(-4);
    }) + '\n';
    const out = new Array(s.length);
    for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i) & 0xff;
    return out;
}

function findExp(mod, name) {
    try {
        if (typeof mod.findExportByName === 'function') return mod.findExportByName(name);
    } catch (_) {}
    try { return Module.findExportByName(mod.name, name); } catch (_) {}
    return null;
}

function readVec3(p) {
    if (!p || p.isNull()) return { x: 0, y: 0, z: 0 };
    return { x: p.readFloat(), y: p.add(4).readFloat(), z: p.add(8).readFloat() };
}

function writeVec3(p, v) {
    if (!p || p.isNull() || !v) return;
    p.writeFloat(v.x);
    p.add(4).writeFloat(v.y);
    p.add(8).writeFloat(v.z);
}

// ---------------------------------------------------------------- il2cpp resolve
function resolveIl2CppExports(mod) {
    const exp = {};
    const names = [
        'il2cpp_domain_get',
        'il2cpp_domain_get_assemblies',
        'il2cpp_assembly_get_image',
        'il2cpp_class_from_name',
        'il2cpp_class_get_method_from_name',
        'il2cpp_image_get_name',
        'il2cpp_thread_attach',
    ];
    for (const n of names) {
        const p = findExp(mod, n);
        if (p && !p.isNull()) exp[n] = p;
    }
    return exp;
}

function findMethodPointer(exp, assemblyName, ns, className, methodName, argsCount) {
    for (const k of ['il2cpp_domain_get', 'il2cpp_domain_get_assemblies', 'il2cpp_assembly_get_image',
        'il2cpp_class_from_name', 'il2cpp_class_get_method_from_name', 'il2cpp_image_get_name']) {
        if (!exp[k]) return ptr(0);
    }
    const domainGet = new NativeFunction(exp.il2cpp_domain_get, 'pointer', []);
    const getAssemblies = new NativeFunction(exp.il2cpp_domain_get_assemblies, 'pointer', ['pointer', 'pointer']);
    const getImage = new NativeFunction(exp.il2cpp_assembly_get_image, 'pointer', ['pointer']);
    const imgGetName = new NativeFunction(exp.il2cpp_image_get_name, 'pointer', ['pointer']);
    const classFromName = new NativeFunction(exp.il2cpp_class_from_name, 'pointer', ['pointer', 'pointer', 'pointer']);
    const methodFromName = new NativeFunction(exp.il2cpp_class_get_method_from_name, 'pointer', ['pointer', 'pointer', 'int']);

    const domain = domainGet();
    if (domain.isNull()) return ptr(0);

    // FIX: thread cua Frida phai attach vao il2cpp truoc khi goi API, neu khong de crash
    if (exp.il2cpp_thread_attach) {
        try { new NativeFunction(exp.il2cpp_thread_attach, 'pointer', ['pointer'])(domain); } catch (_) {}
    }

    const sizePtr = Memory.alloc(Process.pointerSize);
    const assemblies = getAssemblies(domain, sizePtr);
    const count = sizePtr.readU32();

    for (let i = 0; i < count; i++) {
        const asmPtr = assemblies.add(i * Process.pointerSize).readPointer();
        if (asmPtr.isNull()) continue;
        const img = getImage(asmPtr);
        if (img.isNull()) continue;
        const imgName = imgGetName(img).readCString();
        if (imgName === assemblyName || imgName === assemblyName.replace('.dll', '')) {
            const klass = classFromName(img, Memory.allocUtf8String(ns), Memory.allocUtf8String(className));
            if (klass.isNull()) continue;
            const methodInfo = methodFromName(klass, Memory.allocUtf8String(methodName), argsCount);
            if (!methodInfo.isNull()) return methodInfo.readPointer(); // MethodInfo.methodPointer
        }
    }
    return ptr(0);
}

function getTargetAddr(mod, exp, key, assemblyName, ns, className, methodName, argsCount) {
    if (MANUAL_RVA[key] && MANUAL_RVA[key] > 0) return mod.base.add(MANUAL_RVA[key]);
    return findMethodPointer(exp, assemblyName, ns, className, methodName, argsCount);
}

// ---------------------------------------------------------------- commands
function handleCommand(raw) {
    try {
        const cmd = JSON.parse(raw.trim());
        if (cmd.type === 'tp') {
            state._pendingTp = true;
            if (typeof cmd.step === 'number') state.stepForward = clamp(cmd.step, -50, 50);
        } else if (cmd.type === 'pin') {
            state.headPin = !!cmd.enable;
            if (state.headPin && state.lastKnownHead) {
                state.pinnedHeadPos = Object.assign({}, state.lastKnownHead);
            } else if (state.headPin && !state.pinnedHeadPos) {
                state.pinnedHeadPos = { x: 0, y: 1.65, z: 0 };
            }
        } else if (cmd.type === 'aim') {
            state.aimEnabled = !!cmd.enable;
            if (!state.aimEnabled) state.aimTarget = null;
        } else if (cmd.type === 'fly') {
            state.flyEnabled = !!cmd.enable;
            if (typeof cmd.speed === 'number') state.flySpeed = clamp(cmd.speed, 0.1, 10.0);
        } else if (cmd.type === 'fly_speed' && typeof cmd.speed === 'number') {
            state.flySpeed = clamp(cmd.speed, 0.1, 10.0);
        } else if (cmd.type === 'cfg' && cmd.data && typeof cmd.data === 'object') {
            for (const k of CFG_WHITELIST) {
                if (Object.prototype.hasOwnProperty.call(cmd.data, k)) state[k] = cmd.data[k];
            }
        }
    } catch (_) {}
}

// ---------------------------------------------------------------- mock entities
function mockEntities() {
    const t = Date.now() / 1000;
    const a = 0.52 + 0.06 * Math.sin(t * 0.8);
    const b = 0.30 + 0.04 * Math.sin(t * 0.6 + 1.0);
    return [
        { name: 'Bot_Test_01', enemy: true, hp: 100 + 80 * Math.abs(Math.sin(t * 0.3)), maxHp: 200, dist: 24.5,
          nx: a, ny: 0.40, headNx: a, headNy: 0.33 },
        { name: 'Mate_02', enemy: false, hp: 185, maxHp: 200, dist: 12.0,
          nx: b, ny: 0.48, headNx: b, headNy: 0.41 },
    ];
}

function currentEntities() { return useMock ? mockEntities() : externalEntities; }

// ---------------------------------------------------------------- TCP bridge
function startBridgeServer() {
    Socket.listen({ family: 'ipv4', host: HOST, port: PORT }).then(function (listener) {
        function acceptLoop() {
            listener.accept().then(function (conn) {
                let buf = '';
                let timer = null;
                let busy = false;
                let closed = false;

                function cleanup() {
                    if (closed) return;
                    closed = true;
                    if (timer !== null) clearInterval(timer);
                    try { conn.close(); } catch (_) {}
                }

                function readNext() {
                    conn.input.read(4096).then(function (chunk) {
                        if (!chunk || chunk.byteLength === 0) { cleanup(); return; } // EOF
                        buf += bytesToStr(chunk);
                        const lines = buf.split('\n');
                        buf = lines.pop();
                        for (const line of lines) if (line.trim()) handleCommand(line);
                        readNext();
                    }).catch(cleanup);
                }
                readNext();

                timer = setInterval(function () {
                    if (closed || busy) return; // bo qua frame neu ghi chua xong
                    try {
                        busy = true;
                        const payload = asciiBytes({
                            cfg: {
                                espBox: state.espBox, espLine: state.espLine, espDist: state.espDist,
                                espHp: state.espHp, espName: state.espName, rgbMode: state.rgbMode,
                                colorHex: state.colorHex, headPin: state.headPin,
                                aimEnabled: state.aimEnabled, flyEnabled: state.flyEnabled,
                                flySpeed: state.flySpeed,
                            },
                            entities: currentEntities(),
                        });
                        conn.output.write(payload).then(function () { busy = false; }).catch(cleanup);
                    } catch (_) { cleanup(); }
                }, 16);

                acceptLoop();
            }).catch(function () { setTimeout(acceptLoop, 200); });
        }
        acceptLoop();
    }).catch(function (e) {
        console.log('[bridge] listen failed: ' + e + ' -> fallback send()');
        setInterval(function () {
            send({ type: 'esp_frame', cfg: state, entities: currentEntities() });
        }, 16);
    });
}

// ---------------------------------------------------------------- hooks
const attached = { head: false, setPos: false };

function tryAttach(mod, exp) {
    if (!attached.head) {
        const addr = getTargetAddr(mod, exp, 'get_HeadCollider', 'Assembly-CSharp.dll', 'COW.GamePlay', 'AttackableEntity', 'get_HeadCollider', 0);
        if (!addr.isNull()) {
            Interceptor.attach(addr, {
                onLeave: function (retval) {
                    if (!retval.isNull()) state.lastKnownHead = { x: 0, y: 1.65, z: 0 }; // placeholder
                },
            });
            attached.head = true;
            console.log('[hook] get_HeadCollider @ ' + addr);
        }
    }
    if (!attached.setPos) {
        const addr = getTargetAddr(mod, exp, 'set_position_Injected', 'UnityEngine.CoreModule.dll', 'UnityEngine', 'Transform', 'set_position_Injected', 1);
        if (!addr.isNull()) {
            Interceptor.attach(addr, {
                onEnter: function (args) {
                    // FIX: neu da chon player transform thi chi dong vao dung transform do,
                    // neu khong moi object trong scene deu bi tp/bay theo
                    if (playerTransformPtr !== null && !args[0].equals(playerTransformPtr)) return;

                    const vecPtr = args[1];
                    if (!vecPtr || vecPtr.isNull()) return;

                    if (state._pendingTp) {
                        const cur = readVec3(vecPtr);
                        writeVec3(vecPtr, { x: cur.x + state.stepForward, y: cur.y, z: cur.z + state.stepForward });
                        state._pendingTp = false;
                    } else if (state.flyEnabled) {
                        const cur = readVec3(vecPtr);
                        writeVec3(vecPtr, {
                            x: cur.x + 0.02 * state.flySpeed,
                            y: cur.y + 0.04 * state.flySpeed,
                            z: cur.z + 0.02 * state.flySpeed,
                        });
                    } else if (state.headPin && state.pinnedHeadPos) {
                        writeVec3(vecPtr, state.pinnedHeadPos);
                    }

                    if (state.aimEnabled) {
                        const list = currentEntities().filter(function (e) { return e.enemy; });
                        list.sort(function (a, b) {
                            return Math.hypot(a.headNx - 0.5, a.headNy - 0.5) - Math.hypot(b.headNx - 0.5, b.headNy - 0.5);
                        });
                        state.aimTarget = list.length ? { nx: list[0].headNx, ny: list[0].headNy } : null;
                    }
                },
            });
            attached.setPos = true;
            console.log('[hook] Transform.set_position_Injected @ ' + addr);
        }
    }
    return attached.head && attached.setPos;
}

function hookGame(attempt) {
    attempt = attempt || 0;
    const mod = Process.findModuleByName(LIB_IL2CPP);
    if (!mod) { setTimeout(function () { hookGame(attempt); }, 400); return; }

    const exp = resolveIl2CppExports(mod);
    let done = false;
    try { done = tryAttach(mod, exp); } catch (e) { console.log('[hook] error: ' + e); }

    // FIX: assembly co the chua load xong -> thu lai toi da ~30 lan
    if (!done && attempt < 30) {
        setTimeout(function () { hookGame(attempt + 1); }, 1000);
    } else if (!done) {
        console.log('[hook] khong tim thay het method; dien MANUAL_RVA neu can');
    }
}

rpc.exports = {
    tp: function (step) { handleCommand(JSON.stringify({ type: 'tp', step: step })); return true; },
    pin: function (enable) { handleCommand(JSON.stringify({ type: 'pin', enable: enable })); return state.headPin; },
    aim: function (enable) { handleCommand(JSON.stringify({ type: 'aim', enable: enable })); return state.aimEnabled; },
    fly: function (enable, speed) {
        handleCommand(JSON.stringify({ type: 'fly', enable: enable, speed: speed }));
        return { flyEnabled: state.flyEnabled, flySpeed: state.flySpeed };
    },
    setFlySpeed: function (speed) { handleCommand(JSON.stringify({ type: 'fly_speed', speed: speed })); return state.flySpeed; },
    setCfg: function (data) { handleCommand(JSON.stringify({ type: 'cfg', data: data })); return state; },
    // Feed entity that: [{name,enemy,hp,maxHp,dist,nx,ny,headNx,headNy}, ...] (toa do 0..1)
    setEntities: function (list) { externalEntities = list || []; useMock = false; return externalEntities.length; },
    setMock: function (on) { useMock = !!on; return useMock; },
    // Chi tac dong len Transform nay (pointer dang chuoi, vd "0x7b12345678"); null de bo loc
    setPlayerTransform: function (p) { playerTransformPtr = p ? ptr(p) : null; return playerTransformPtr ? playerTransformPtr.toString() : null; },
};

setImmediate(function () {
    startBridgeServer();
    hookGame(0);
});

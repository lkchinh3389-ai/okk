'use strict';

// ff_real_hook.js - Ban dung offset THAT (com_dts_freefireth__x64__cs.txt), cho server rieng test.
// Lay entity bang cach hook Player.get_IsDieing/IsVisible/get_CurHP (khong can offset danh sach player),
// doi sang toa do man hinh bang Camera.WorldToScreenPoint, day sang app overlay qua 127.0.0.1:27111.

const LIB = 'libil2cpp.so';
const HOST = '127.0.0.1';
const PORT = 27111;

// Chi chay khi versionName bat dau bang chuoi nay (offset chi dung cho dung ban build). '' = bo qua kiem tra.
const REQUIRE_VERSION_PREFIX = '1.70';

const RVA = {
    CurrentLocalPlayer: 0x20CE148,
    get_transform: 0x3E117AC,
    get_position_Injected: 0x3C3912C,
    set_position_Injected: 0x3C391C8,
    get_forward: 0x3C39A8C,
    Camera_get_main: 0x3E0FE00,
    WorldToScreenPoint: 0x3E0F7E8,
    get_CurHP: 0x18C94A0,
    get_MaxHP: 0x18C95A4,
    get_IsDieing: 0x1892408,
    IsVisible: 0x1896840,
    IsLocalTeammate: 0x189DB10,
    SetAimRotation: 0x1893738,
};
const OFF = { MainCameraTransform: 0xD8, IsClientBot: 0x178 };

// Tinh chinh
const cfgTune = {
    headH: 1.75,        // chieu cao dinh dau so voi pivot (m)
    aimH: 1.55,         // diem ngam (m)
    pivotY: 0.0,        // neu pivot khong nam o chan, chinh so nay
    renderScale: 1.0,   // neu game render thap hon man hinh thi chinh (vd 0.75)
    screenW: 0, screenH: 0, // 0 = tu lay tu Android
    aimFov: 0.2,        // ban kinh vong aim = aimFov * min(W,H) (khop voi overlay)
};

const state = {
    espBox: true, espLine: true, espDist: true, espHp: true, espName: true,
    rgbMode: true, colorHex: '#FF3B30',
    headPin: false,       // "pin" = khoa vi tri nhan vat tai cho hien tai
    aimEnabled: false,
    flyEnabled: false, flySpeed: 1.5,
    stepForward: 2.5,
    _pendingTp: false,
};
const CFG_WHITELIST = ['espBox', 'espLine', 'espDist', 'espHp', 'espName', 'rgbMode', 'colorHex',
    'headPin', 'aimEnabled', 'flyEnabled', 'flySpeed', 'stepForward'];

let F = null;                 // native functions
let base = null;
let jsTid = -1;
let screenW = 1920, screenH = 1080;
let entities = [];
let targets = [];             // {ent, wx, wy, wz} dung cho aim
let localPlayer = ptr(0);
let localTransform = ptr(0);
let localMct = ptr(0);        // MainCameraTransform cua local player
let pinPos = null;
let attached = false;
let camPtr = ptr(0), camAt = 0;
const seen = new Map();       // key -> {p, t}
const ids = new Map();
const vbuf = Memory.alloc(16);
let lastErr = 0;

function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
function valid(p) { return p !== null && !p.isNull() && p.compare(ptr('0x10000')) > 0; }

// ---------------------------------------------------------------- util
function bytesToStr(buf) {
    const u8 = new Uint8Array(buf);
    let s = '';
    for (let i = 0; i < u8.length; i++) s += String.fromCharCode(u8[i]);
    return s;
}
function asciiBytes(obj) {
    const s = JSON.stringify(obj).replace(/[\u007f-\uffff]/g, function (c) {
        return '\\u' + ('0000' + c.charCodeAt(0).toString(16)).slice(-4);
    }) + '\n';
    const out = new Array(s.length);
    for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i) & 0xff;
    return out;
}
function findExp(mod, name) {
    try { if (typeof mod.findExportByName === 'function') return mod.findExportByName(name); } catch (_) {}
    try { return Module.findExportByName(mod.name, name); } catch (_) {}
    return null;
}

// ---------------------------------------------------------------- natives
function bindNatives(mod) {
    const A = function (n) { return mod.base.add(RVA[n]); };
    const P = 'pointer';
    const V3 = ['float', 'float', 'float'];
    const Q4 = ['float', 'float', 'float', 'float'];
    F = {
        localPlayer: new NativeFunction(A('CurrentLocalPlayer'), P, [P]),
        getTransform: new NativeFunction(A('get_transform'), P, [P, P]),
        getPos: new NativeFunction(A('get_position_Injected'), 'void', [P, P, P]),
        getForward: new NativeFunction(A('get_forward'), V3, [P, P]),
        camMain: new NativeFunction(A('Camera_get_main'), P, [P]),
        w2s: new NativeFunction(A('WorldToScreenPoint'), V3, [P, V3, P]),
        curHp: new NativeFunction(A('get_CurHP'), 'int', [P, P]),
        maxHp: new NativeFunction(A('get_MaxHP'), 'int', [P, P]),
        isDying: new NativeFunction(A('get_IsDieing'), 'uint8', [P, P]),
        isTeammate: new NativeFunction(A('IsLocalTeammate'), 'uint8', [P, P]),
        setAimRot: new NativeFunction(A('SetAimRotation'), 'void', [P, Q4, P]),
    };
}

function attachIl2cppThread(mod) {
    try {
        const dg = findExp(mod, 'il2cpp_domain_get');
        const ta = findExp(mod, 'il2cpp_thread_attach');
        if (dg && ta) {
            const domain = new NativeFunction(dg, 'pointer', [])();
            new NativeFunction(ta, 'pointer', ['pointer'])(domain);
            console.log('[il2cpp] thread attached');
        }
    } catch (e) { console.log('[il2cpp] attach failed: ' + e); }
}

function posOf(p) {
    const tr = F.getTransform(p, ptr(0));
    if (!valid(tr)) return null;
    F.getPos(tr, vbuf, ptr(0));
    return { x: vbuf.readFloat(), y: vbuf.add(4).readFloat(), z: vbuf.add(8).readFloat(), tr: tr };
}

function lookRotation(fx, fy, fz) {
    const l = Math.hypot(fx, fy, fz);
    if (l < 1e-6) return null;
    fx /= l; fy /= l; fz /= l;
    let rx = fz, rz = -fx;                       // cross(up, f)
    const rl = Math.hypot(rx, rz);
    if (rl < 1e-6) { rx = 1; rz = 0; } else { rx /= rl; rz /= rl; }
    const ry = 0;
    const ux = fy * rz - fz * ry, uy = fz * rx - fx * rz, uz = fx * ry - fy * rx;
    const m00 = rx, m01 = ux, m02 = fx, m10 = ry, m11 = uy, m12 = fy, m20 = rz, m21 = uz, m22 = fz;
    const tr = m00 + m11 + m22;
    let x, y, z, w, s;
    if (tr > 0) { s = Math.sqrt(tr + 1) * 2; w = 0.25 * s; x = (m21 - m12) / s; y = (m02 - m20) / s; z = (m10 - m01) / s; }
    else if (m00 > m11 && m00 > m22) { s = Math.sqrt(1 + m00 - m11 - m22) * 2; w = (m21 - m12) / s; x = 0.25 * s; y = (m01 + m10) / s; z = (m02 + m20) / s; }
    else if (m11 > m22) { s = Math.sqrt(1 + m11 - m00 - m22) * 2; w = (m02 - m20) / s; x = (m01 + m10) / s; y = 0.25 * s; z = (m12 + m21) / s; }
    else { s = Math.sqrt(1 + m22 - m00 - m11) * 2; w = (m10 - m01) / s; x = (m02 + m20) / s; y = (m12 + m21) / s; z = 0.25 * s; }
    return [x, y, z, w];
}

// ---------------------------------------------------------------- tick (30Hz)
function shortId(k) {
    if (!ids.has(k)) ids.set(k, ids.size + 1);
    return ids.get(k);
}

function tick() {
    if (!F) return;
    try {
        const now = Date.now();
        const W = (cfgTune.screenW || screenW) * cfgTune.renderScale;
        const H = (cfgTune.screenH || screenH) * cfgTune.renderScale;

        for (const [k, e] of seen) if (now - e.t > 1500) seen.delete(k);

        const lp = F.localPlayer(ptr(0));
        localPlayer = valid(lp) ? lp : ptr(0);
        let lpos = null;
        if (valid(localPlayer)) {
            lpos = posOf(localPlayer);
            localTransform = lpos ? lpos.tr : ptr(0);
            try { localMct = localPlayer.add(OFF.MainCameraTransform).readPointer(); } catch (_) { localMct = ptr(0); }
        } else {
            localTransform = ptr(0); localMct = ptr(0);
        }

        // pin = khoa vi tri
        if (state.headPin && !pinPos && lpos) pinPos = { x: lpos.x, y: lpos.y, z: lpos.z };
        if (!state.headPin) pinPos = null;

        if (!valid(camPtr) || now - camAt > 500) { camPtr = F.camMain(ptr(0)); camAt = now; }
        if (!valid(camPtr)) { entities = []; targets = []; return; }

        const outEnt = [], outTgt = [];
        for (const [k, e] of seen) {
            if (now - e.t > 400) continue;                 // chi lay entity vua duoc game goi
            const p = e.p;
            if (valid(localPlayer) && p.equals(localPlayer)) continue;
            if (F.isDying(p, ptr(0)) !== 0) continue;
            const hp = F.curHp(p, ptr(0));
            const mx = F.maxHp(p, ptr(0));
            if (hp <= 0 || mx <= 0 || mx > 100000) continue;
            const pos = posOf(p);
            if (!pos) continue;

            const y0 = pos.y + cfgTune.pivotY;
            const bot = F.w2s(camPtr, [pos.x, y0, pos.z], ptr(0));
            const top = F.w2s(camPtr, [pos.x, y0 + cfgTune.headH, pos.z], ptr(0));
            const aim = F.w2s(camPtr, [pos.x, y0 + cfgTune.aimH, pos.z], ptr(0));
            if (bot[2] <= 0 || top[2] <= 0) continue;       // sau camera

            const boxH = Math.abs(top[1] - bot[1]) / H * 1.05;
            const ent = {
                name: (p.add(OFF.IsClientBot).readU8() ? 'Bot ' : 'P ') + shortId(k),
                enemy: F.isTeammate(p, ptr(0)) === 0,
                hp: hp, maxHp: mx,
                dist: lpos ? Math.hypot(pos.x - lpos.x, pos.y - lpos.y, pos.z - lpos.z) : 0,
                nx: bot[0] / W,
                ny: 1 - ((bot[1] + top[1]) / 2) / H,
                headNx: aim[0] / W,
                headNy: 1 - aim[1] / H,
                boxH: boxH,
                boxW: boxH * H / W * 0.5,
            };
            outEnt.push(ent);
            outTgt.push({ ent: ent, wx: pos.x, wy: y0 + cfgTune.aimH, wz: pos.z });
        }
        entities = outEnt;
        targets = outTgt;

        // ---- aim: xoay local player toi muc tieu gan tam nhat trong vong FOV
        if (state.aimEnabled && valid(localPlayer) && lpos) {
            const fovPx = cfgTune.aimFov * Math.min(W, H);
            let best = null, bestD = 1e9;
            for (const t of outTgt) {
                if (!t.ent.enemy) continue;
                const d = Math.hypot((t.ent.headNx - 0.5) * W, (t.ent.headNy - 0.5) * H);
                if (d <= fovPx && d < bestD) { bestD = d; best = t; }
            }
            if (best) {
                let ox = lpos.x, oy = lpos.y + 1.6, oz = lpos.z;
                if (valid(localMct)) {
                    F.getPos(localMct, vbuf, ptr(0));
                    ox = vbuf.readFloat(); oy = vbuf.add(4).readFloat(); oz = vbuf.add(8).readFloat();
                }
                const q = lookRotation(best.wx - ox, best.wy - oy, best.wz - oz);
                if (q) F.setAimRot(localPlayer, q, ptr(0));
            }
        }
    } catch (e) {
        if (Date.now() - lastErr > 3000) { console.log('[tick] ' + e); lastErr = Date.now(); }
    }
}

// ---------------------------------------------------------------- commands
function handleCommand(raw) {
    try {
        const cmd = JSON.parse(raw.trim());
        if (cmd.type === 'tp') {
            state._pendingTp = true;
            if (typeof cmd.step === 'number') state.stepForward = clamp(cmd.step, -50, 50);
        } else if (cmd.type === 'pin') {
            state.headPin = !!cmd.enable;
            if (!state.headPin) pinPos = null;
        } else if (cmd.type === 'aim') {
            state.aimEnabled = !!cmd.enable;
        } else if (cmd.type === 'fly') {
            state.flyEnabled = !!cmd.enable;
            if (typeof cmd.speed === 'number') state.flySpeed = clamp(cmd.speed, 0.1, 10.0);
        } else if (cmd.type === 'fly_speed' && typeof cmd.speed === 'number') {
            state.flySpeed = clamp(cmd.speed, 0.1, 10.0);
        } else if (cmd.type === 'cfg' && cmd.data && typeof cmd.data === 'object') {
            for (const k of CFG_WHITELIST) {
                if (Object.prototype.hasOwnProperty.call(cmd.data, k)) state[k] = cmd.data[k];
            }
        }
    } catch (_) {}
}

// ---------------------------------------------------------------- TCP bridge
function startBridgeServer() {
    Socket.listen({ family: 'ipv4', host: HOST, port: PORT }).then(function (listener) {
        function acceptLoop() {
            listener.accept().then(function (conn) {
                let buf = '', timer = null, busy = false, closed = false;
                function cleanup() {
                    if (closed) return;
                    closed = true;
                    if (timer !== null) clearInterval(timer);
                    try { conn.close(); } catch (_) {}
                }
                function readNext() {
                    conn.input.read(4096).then(function (chunk) {
                        if (!chunk || chunk.byteLength === 0) { cleanup(); return; }
                        buf += bytesToStr(chunk);
                        const lines = buf.split('\n');
                        buf = lines.pop();
                        for (const line of lines) if (line.trim()) handleCommand(line);
                        readNext();
                    }).catch(cleanup);
                }
                readNext();
                timer = setInterval(function () {
                    if (closed || busy) return;
                    try {
                        busy = true;
                        conn.output.write(asciiBytes({
                            cfg: {
                                espBox: state.espBox, espLine: state.espLine, espDist: state.espDist,
                                espHp: state.espHp, espName: state.espName, rgbMode: state.rgbMode,
                                colorHex: state.colorHex, headPin: state.headPin,
                                aimEnabled: state.aimEnabled, flyEnabled: state.flyEnabled,
                                flySpeed: state.flySpeed,
                            },
                            entities: entities,
                        })).then(function () { busy = false; }).catch(cleanup);
                    } catch (_) { cleanup(); }
                }, 16);
                acceptLoop();
            }).catch(function () { setTimeout(acceptLoop, 200); });
        }
        acceptLoop();
    }).catch(function (e) { console.log('[bridge] listen failed: ' + e); });
}

// ---------------------------------------------------------------- hooks
function noteSeen(p) {
    const k = p.toString();
    const e = seen.get(k);
    if (e) e.t = Date.now(); else seen.set(k, { p: p, t: Date.now() });
}

function installHooks(mod) {
    if (attached) return;
    attached = true;
    const A = function (n) { return mod.base.add(RVA[n]); };

    // thu thap Player instance dang duoc game goi (bo qua cac lan goi tu chinh script)
    ['get_IsDieing', 'IsVisible', 'get_CurHP'].forEach(function (n) {
        Interceptor.attach(A(n), {
            onEnter: function (args) {
                if (this.threadId === jsTid) return;
                if (valid(args[0])) noteSeen(args[0]);
            },
        });
    });

    // tp / fly / pin: chi tac dong len Transform cua local player
    Interceptor.attach(A('set_position_Injected'), {
        onEnter: function (args) {
            if (!valid(localTransform) || !args[0].equals(localTransform)) return;
            if (this.threadId === jsTid) return;
            const v = args[1];
            if (!valid(v)) return;
            try {
                if (state._pendingTp) {
                    state._pendingTp = false;
                    let fx = 0, fz = 1;
                    if (valid(localMct)) {
                        const f = F.getForward(localMct, ptr(0));
                        const l = Math.hypot(f[0], f[2]) || 1;
                        fx = f[0] / l; fz = f[2] / l;
                    }
                    v.writeFloat(v.readFloat() + fx * state.stepForward);
                    v.add(8).writeFloat(v.add(8).readFloat() + fz * state.stepForward);
                } else if (state.flyEnabled) {
                    v.add(4).writeFloat(v.add(4).readFloat() + 0.05 * state.flySpeed);
                } else if (state.headPin && pinPos) {
                    v.writeFloat(pinPos.x); v.add(4).writeFloat(pinPos.y); v.add(8).writeFloat(pinPos.z);
                }
            } catch (_) {}
        },
    });
    console.log('[hook] installed');
}

// ---------------------------------------------------------------- start
function refreshScreenAndCheckVersion(done) {
    if (!Java.available) {
        console.log('[warn] Java khong kha dung: dung man hinh mac dinh, bo qua kiem tra phien ban. Dung rpc setScreen(w,h).');
        done(true);
        return;
    }
    let tries = 0;
    (function attempt() {
        Java.perform(function () {
            try {
                const AT = Java.use('android.app.ActivityThread');
                const app = AT.currentApplication();
                if (app === null) {
                    if (++tries < 40) { setTimeout(attempt, 500); return; }
                    console.log('[warn] khong lay duoc Application, bo qua kiem tra phien ban');
                    done(true);
                    return;
                }
                const dm = Java.use('android.content.res.Resources').getSystem().getDisplayMetrics();
                const w = dm.widthPixels.value, h = dm.heightPixels.value;
                screenW = Math.max(w, h); screenH = Math.min(w, h);
                const ver = String(app.getPackageManager().getPackageInfo(app.getPackageName(), 0).versionName.value);
                console.log('[info] version=' + ver + ' screen=' + screenW + 'x' + screenH);
                if (REQUIRE_VERSION_PREFIX && ver.indexOf(REQUIRE_VERSION_PREFIX) !== 0) {
                    console.log('[stop] phien ban ' + ver + ' khong khop offset (can ' + REQUIRE_VERSION_PREFIX + '.x). Khong hook.');
                    done(false);
                    return;
                }
                done(true);
            } catch (e) {
                console.log('[warn] check loi: ' + e);
                done(true);
            }
        });
    })();
}

function waitModule(cb) {
    const m = Process.findModuleByName(LIB);
    if (!m) { setTimeout(function () { waitModule(cb); }, 400); return; }
    cb(m);
}

rpc.exports = {
    status: function () {
        return {
            seen: seen.size, entities: entities.length, localPlayer: String(localPlayer),
            localTransform: String(localTransform), screen: [screenW, screenH],
            state: state, tune: cfgTune,
        };
    },
    setScreen: function (w, h) { cfgTune.screenW = w; cfgTune.screenH = h; return [w, h]; },
    tune: function (k, v) { if (k in cfgTune) cfgTune[k] = v; return cfgTune; },
    tp: function (step) { handleCommand(JSON.stringify({ type: 'tp', step: step })); return true; },
    fly: function (on, speed) { handleCommand(JSON.stringify({ type: 'fly', enable: on, speed: speed })); return state.flyEnabled; },
    aim: function (on) { handleCommand(JSON.stringify({ type: 'aim', enable: on })); return state.aimEnabled; },
    pin: function (on) { handleCommand(JSON.stringify({ type: 'pin', enable: on })); return state.headPin; },
};

setImmediate(function () {
    jsTid = Process.getCurrentThreadId();
    startBridgeServer();
    refreshScreenAndCheckVersion(function (ok) {
        if (!ok) return;
        waitModule(function (mod) {
            // cho il2cpp khoi tao xong roi moi goi
            setTimeout(function () {
                bindNatives(mod);
                attachIl2cppThread(mod);
                installHooks(mod);
                setInterval(tick, 33);
                console.log('[ready] base=' + mod.base);
            }, 3000);
        });
    });
});

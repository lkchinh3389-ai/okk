package com.test.overlay;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;
import android.view.animation.LinearInterpolator;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class EspOverlayView extends View {
    public static class EntityBox {
        public String name = "Target";
        public boolean enemy = true;
        public float hp = 100f;
        public float maxHp = 200f;
        public float dist = 15f;
        public float nx = 0.5f;
        public float ny = 0.38f;
        public float headNx = 0.5f;
        public float headNy = 0.30f;
        public float boxW = 0f;   // chuan hoa theo chieu rong man hinh (0 = tu tinh)
        public float boxH = 0f;   // chuan hoa theo chieu cao man hinh (0 = tu tinh)
    }

    private final EspConfig cfg;
    private final float density;

    private final Paint boxPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint chipPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hpBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hpFgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint aimPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final RectF rect = new RectF();
    private final float[] pts = new float[32];
    private final float[] hsv = new float[]{0f, 1f, 1f};

    private volatile List<EntityBox> entities = new ArrayList<>();
    private boolean connected = false;
    private float hue = 0f;
    private ValueAnimator anim;

    public EspOverlayView(Context context, EspConfig cfg) {
        super(context);
        this.cfg = cfg;
        this.density = context.getResources().getDisplayMetrics().density;

        boxPaint.setStyle(Paint.Style.STROKE);
        boxPaint.setStrokeWidth(dp(1.6f));
        boxPaint.setStrokeCap(Paint.Cap.ROUND);

        linePaint.setStyle(Paint.Style.STROKE);
        linePaint.setStrokeWidth(dp(1.1f));

        textPaint.setTextSize(dp(10.5f));
        textPaint.setFakeBoldText(true);

        chipPaint.setStyle(Paint.Style.FILL);
        hpBgPaint.setStyle(Paint.Style.FILL);
        hpBgPaint.setColor(Color.argb(170, 20, 20, 24));
        hpFgPaint.setStyle(Paint.Style.FILL);

        aimPaint.setStyle(Paint.Style.STROKE);
        aimPaint.setStrokeWidth(dp(1.4f));
        dotPaint.setStyle(Paint.Style.FILL);
    }

    private float dp(float v) {
        return v * density;
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        anim = ValueAnimator.ofFloat(0f, 360f);
        anim.setDuration(2400);
        anim.setRepeatCount(ValueAnimator.INFINITE);
        anim.setInterpolator(new LinearInterpolator());
        anim.addUpdateListener(a -> {
            hue = (float) a.getAnimatedValue();
            if (cfg.rgb) invalidate();
        });
        anim.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (anim != null) {
            anim.cancel();
            anim = null;
        }
        super.onDetachedFromWindow();
    }

    public void setConnected(boolean c) {
        this.connected = c;
        invalidate();
    }

    public void setEntities(List<EntityBox> list) {
        if (list != null) {
            this.entities = list;
            invalidate();
        }
    }

    private int entityColor(boolean enemy) {
        if (!enemy) return 0xFF38BDF8;
        if (cfg.rgb) {
            hsv[0] = hue;
            return Color.HSVToColor(hsv);
        }
        return cfg.color;
    }

    private float chip(Canvas c, String s, float cx, float top, int bg, int fg) {
        textPaint.setColor(fg);
        float tw = textPaint.measureText(s);
        float padX = dp(6f);
        float padY = dp(3f);
        Paint.FontMetrics fm = textPaint.getFontMetrics();
        float th = fm.descent - fm.ascent;
        rect.set(cx - tw / 2f - padX, top, cx + tw / 2f + padX, top + th + padY * 2f);
        chipPaint.setColor(bg);
        c.drawRoundRect(rect, dp(8f), dp(8f), chipPaint);
        c.drawText(s, cx - tw / 2f, top + padY - fm.ascent, textPaint);
        return th + padY * 2f;
    }

    private void corners(Canvas c, float l, float t, float r, float b, Paint p) {
        float len = Math.min(r - l, b - t) * 0.32f;
        int i = 0;
        pts[i++] = l; pts[i++] = t; pts[i++] = l + len; pts[i++] = t;
        pts[i++] = l; pts[i++] = t; pts[i++] = l; pts[i++] = t + len;
        pts[i++] = r; pts[i++] = t; pts[i++] = r - len; pts[i++] = t;
        pts[i++] = r; pts[i++] = t; pts[i++] = r; pts[i++] = t + len;
        pts[i++] = l; pts[i++] = b; pts[i++] = l + len; pts[i++] = b;
        pts[i++] = l; pts[i++] = b; pts[i++] = l; pts[i++] = b - len;
        pts[i++] = r; pts[i++] = b; pts[i++] = r - len; pts[i++] = b;
        pts[i++] = r; pts[i++] = b; pts[i++] = r; pts[i++] = b - len;
        c.drawLines(pts, 0, i, p);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        final float w = getWidth();
        final float h = getHeight();
        if (w <= 0 || h <= 0) return;

        float chipY = dp(8f);
        if (!connected) {
            chipY += chip(canvas, "Chờ game kết nối · 127.0.0.1:" + OverlayService.PORT,
                    w / 2f, chipY, 0xB3000000, 0xFFFFC857) + dp(4f);
        }
        if (cfg.fly) {
            chip(canvas, String.format(Locale.US, "FLY x%.1f", cfg.flySpeed),
                    w / 2f, chipY, 0xB3000000, 0xFF34D399);
        }

        final List<EntityBox> list = entities;
        EntityBox nearest = null;
        float nearestScore = Float.MAX_VALUE;

        for (EntityBox e : list) {
            if (e == null || Float.isNaN(e.nx) || Float.isNaN(e.ny)) continue;
            if (e.nx < -0.2f || e.nx > 1.2f || e.ny < -0.2f || e.ny > 1.2f) continue;

            int col = entityColor(e.enemy);
            float scale = Math.max(0.55f, Math.min(1.6f, 18f / Math.max(e.dist, 1f)));
            float cx = e.nx * w;
            float cy = e.ny * h;
            float bh = e.boxH > 0f ? e.boxH * h : h * 0.2f * scale;
            float bw = e.boxW > 0f ? e.boxW * w : bh * 0.5f;
            float l = cx - bw / 2f, t = cy - bh / 2f, r = cx + bw / 2f, b = cy + bh / 2f;
            float headX = e.headNx * w;
            float headY = e.headNy * h;

            if (cfg.line && e.enemy) {
                linePaint.setColor(col);
                linePaint.setAlpha(190);
                canvas.drawLine(w / 2f, 0f, headX, headY, linePaint);
                dotPaint.setColor(col);
                canvas.drawCircle(headX, headY, dp(2.6f), dotPaint);
            }

            if (cfg.box) {
                boxPaint.setColor(col);
                corners(canvas, l, t, r, b, boxPaint);
            }

            if (cfg.hp) {
                float ratio = e.maxHp > 0 ? Math.max(0f, Math.min(1f, e.hp / e.maxHp)) : 0f;
                float bx = l - dp(5f);
                rect.set(bx - dp(3f), t, bx, b);
                canvas.drawRoundRect(rect, dp(2f), dp(2f), hpBgPaint);
                float fillTop = b - (b - t) * ratio;
                rect.set(bx - dp(3f), fillTop, bx, b);
                float[] c2 = new float[]{ratio * 120f, 0.85f, 1f};
                hpFgPaint.setColor(Color.HSVToColor(c2));
                canvas.drawRoundRect(rect, dp(2f), dp(2f), hpFgPaint);
            }

            if (cfg.name || cfg.dist) {
                String label;
                if (cfg.name && cfg.dist) label = e.name + "  " + Math.round(e.dist) + "m";
                else if (cfg.name) label = e.name;
                else label = Math.round(e.dist) + "m";
                Paint.FontMetrics fm = textPaint.getFontMetrics();
                float chipH = (fm.descent - fm.ascent) + dp(6f);
                chip(canvas, label, cx, t - chipH - dp(3f), 0xA6000000, e.enemy ? 0xFFFFFFFF : 0xFF7DD3FC);
            }

            if (e.enemy) {
                float score = (float) Math.hypot(e.headNx - 0.5f, e.headNy - 0.5f);
                if (score < nearestScore) {
                    nearestScore = score;
                    nearest = e;
                }
            }
        }

        if (cfg.aim) {
            aimPaint.setColor(0x99FFD60A);
            canvas.drawCircle(w / 2f, h / 2f, Math.min(w, h) * 0.2f, aimPaint);
            if (nearest != null) {
                aimPaint.setColor(0xFFFFD60A);
                canvas.drawLine(w / 2f, h / 2f, nearest.headNx * w, nearest.headNy * h, aimPaint);
            }
        }
    }
}

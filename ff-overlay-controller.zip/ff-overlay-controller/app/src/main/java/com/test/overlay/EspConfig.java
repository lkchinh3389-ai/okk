package com.test.overlay;

/** Cau hinh hien thi + trang thai cac tinh nang phia game (dung chung giua overlay va panel). */
final class EspConfig {
    boolean box = true;
    boolean line = true;
    boolean dist = true;
    boolean hp = true;
    boolean name = true;
    boolean rgb = true;
    boolean aim = false;
    boolean fly = false;
    boolean headPin = false;
    int color = 0xFFFF3B30;
    float flySpeed = 1.5f;
}

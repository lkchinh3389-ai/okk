package com.test.overlay;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.content.res.ColorStateList;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import androidx.core.app.NotificationCompat;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;
import java.util.Locale;

public class OverlayService extends Service implements BridgeClient.Listener {
    static final String ACTION_START = "com.test.overlay.START";
    static final String ACTION_STOP = "com.test.overlay.STOP";
    static final String CHANNEL_ID = "overlay_channel";
    static final int NOTIF_ID = 1001;
    static final int PORT = 27111;
    static volatile boolean running = false;

    private WindowManager wm;
    private final EspConfig cfg = new EspConfig();
    private EspOverlayView esp;
    private LinearLayout menuRoot;
    private WindowManager.LayoutParams menuLp;
    private ScrollView panelScroll;
    private LinearLayout panelContent;
    private boolean panelOpen = false;
    private BridgeClient client;
    private boolean synced = false;
    private boolean updatingUi = false;

    private TextView statusText;
    private View statusDot;
    private Switch swBox, swLine, swDist, swHp, swName, swRgb, swFly, swAim, swPin;
    private SeekBar speedBar;
    private TextView speedLabel;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        startForegroundCompat();
        if (ACTION_STOP.equals(action) || !Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!running) setup();
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        if (client != null) client.stop();
        removeQuietly(esp);
        removeQuietly(menuRoot);
        super.onDestroy();
    }

    // ------------------------------------------------------------------ foreground

    private void startForegroundCompat() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Overlay", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
        int piFlags = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), piFlags);
        Intent stop = new Intent(this, OverlayService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop, piFlags);

        Notification n = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("FF Test Overlay đang chạy")
                .setContentText("Đang chờ kết nối 127.0.0.1:" + PORT)
                .setContentIntent(open)
                .addAction(R.drawable.ic_stat, "Dừng", stopPi)
                .setOngoing(true)
                .build();

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    // ------------------------------------------------------------------ setup

    private int overlayType() {
        return Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private void setup() {
        running = true;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        try {
            esp = new EspOverlayView(this, cfg);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    overlayType(),
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            if (Build.VERSION.SDK_INT >= 28) {
                lp.layoutInDisplayCutoutMode =
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            }
            wm.addView(esp, lp);

            buildMenu();
            wm.addView(menuRoot, menuLp);
        } catch (Exception e) {
            stopSelf();
            return;
        }
        client = new BridgeClient("127.0.0.1", PORT, this);
        client.start();
    }

    private void removeQuietly(View v) {
        if (v == null || wm == null) return;
        try {
            wm.removeView(v);
        } catch (Exception ignored) {
        }
    }

    // ------------------------------------------------------------------ commands

    private void cmd(String type, Object... kv) {
        if (client == null) return;
        try {
            JSONObject o = new JSONObject();
            o.put("type", type);
            for (int i = 0; i + 1 < kv.length; i += 2) o.put((String) kv[i], kv[i + 1]);
            client.send(o.toString());
        } catch (JSONException ignored) {
        }
    }

    private void sendCfg(String key, Object value) {
        if (client == null) return;
        try {
            JSONObject data = new JSONObject();
            data.put(key, value);
            JSONObject o = new JSONObject();
            o.put("type", "cfg");
            o.put("data", data);
            client.send(o.toString());
        } catch (JSONException ignored) {
        }
    }

    // ------------------------------------------------------------------ BridgeClient.Listener

    @Override
    public void onConnection(boolean c) {
        if (esp != null) esp.setConnected(c);
        if (!c) synced = false;
        if (statusText != null) {
            statusText.setText(c ? "Đã kết nối game" : "Chờ game kết nối…");
            statusDot.setBackground(Ui.circle(c ? Ui.OK : Ui.BAD));
        }
    }

    @Override
    public void onFrame(EspConfig rc, List<EspOverlayView.EntityBox> entities) {
        if (rc != null && !synced) {
            synced = true;
            cfg.fly = rc.fly;
            cfg.aim = rc.aim;
            cfg.headPin = rc.headPin;
            cfg.flySpeed = rc.flySpeed;
            syncUi();
        }
        if (esp != null) esp.setEntities(entities);
    }

    // ------------------------------------------------------------------ menu UI

    private Switch makeSwitch(boolean initial, CompoundButton.OnCheckedChangeListener l) {
        Switch s = new Switch(this);
        s.setChecked(initial);
        int[][] st = new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}};
        s.setThumbTintList(new ColorStateList(st, new int[]{Ui.ACCENT, 0xFFB0B7C6}));
        s.setTrackTintList(new ColorStateList(st, new int[]{0x66FF3B30, 0x44FFFFFF}));
        s.setOnCheckedChangeListener((b, on) -> {
            if (!updatingUi) l.onCheckedChanged(b, on);
        });
        return s;
    }

    private void addRow(LinearLayout parent, String label, Switch sw) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = Ui.text(this, label, 13f, Ui.TEXT, false);
        row.addView(t, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(sw);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, 2);
        parent.addView(row, lp);
    }

    private void addSection(LinearLayout parent, String title) {
        TextView t = Ui.text(this, title.toUpperCase(Locale.ROOT), 10.5f, Ui.MUTED, true);
        t.setLetterSpacing(0.12f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, 12);
        lp.bottomMargin = Ui.dp(this, 2);
        parent.addView(t, lp);
    }

    private TextView makeButton(String label, int from, int to) {
        TextView b = Ui.text(this, label, 13f, 0xFFFFFFFF, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(Ui.gradient(this, from, to, 10));
        int p = Ui.dp(this, 10);
        b.setPadding(p, p, p, p);
        return b;
    }

    private void buildMenu() {
        menuRoot = new LinearLayout(this);
        menuRoot.setOrientation(LinearLayout.VERTICAL);

        // bubble
        TextView bubble = Ui.text(this, "◎", 20f, 0xFFFFFFFF, true);
        bubble.setGravity(Gravity.CENTER);
        bubble.setBackground(Ui.gradient(this, Ui.ACCENT, Ui.ACCENT2, 24));
        bubble.setElevation(Ui.dp(this, 6));
        int bs = Ui.dp(this, 44);
        menuRoot.addView(bubble, new LinearLayout.LayoutParams(bs, bs));

        // panel
        panelContent = new LinearLayout(this);
        panelContent.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(this, 14);
        panelContent.setPadding(pad, pad, pad, pad);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(Ui.text(this, "FF Test Overlay", 15f, Ui.TEXT, true),
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        statusDot = new View(this);
        statusDot.setBackground(Ui.circle(Ui.BAD));
        LinearLayout.LayoutParams dotLp = new LinearLayout.LayoutParams(Ui.dp(this, 8), Ui.dp(this, 8));
        dotLp.rightMargin = Ui.dp(this, 6);
        head.addView(statusDot, dotLp);
        statusText = Ui.text(this, "Chờ game kết nối…", 11f, Ui.MUTED, false);
        head.addView(statusText);
        panelContent.addView(head);

        addSection(panelContent, "ESP");
        swBox = makeSwitch(cfg.box, (b, on) -> { cfg.box = on; esp.invalidate(); sendCfg("espBox", on); });
        addRow(panelContent, "Hộp (box)", swBox);
        swLine = makeSwitch(cfg.line, (b, on) -> { cfg.line = on; esp.invalidate(); sendCfg("espLine", on); });
        addRow(panelContent, "Đường kẻ (line)", swLine);
        swDist = makeSwitch(cfg.dist, (b, on) -> { cfg.dist = on; esp.invalidate(); sendCfg("espDist", on); });
        addRow(panelContent, "Khoảng cách", swDist);
        swHp = makeSwitch(cfg.hp, (b, on) -> { cfg.hp = on; esp.invalidate(); sendCfg("espHp", on); });
        addRow(panelContent, "Thanh máu", swHp);
        swName = makeSwitch(cfg.name, (b, on) -> { cfg.name = on; esp.invalidate(); sendCfg("espName", on); });
        addRow(panelContent, "Tên", swName);
        swRgb = makeSwitch(cfg.rgb, (b, on) -> { cfg.rgb = on; esp.invalidate(); sendCfg("rgbMode", on); });
        addRow(panelContent, "Màu RGB", swRgb);

        // colour chips
        final int[] colors = {0xFFFF3B30, 0xFFFF9500, 0xFFFFD60A, 0xFF34C759, 0xFF0A84FF, 0xFFBF5AF2};
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        for (int col : colors) {
            View chip = new View(this);
            chip.setBackground(Ui.circle(col));
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(Ui.dp(this, 22), Ui.dp(this, 22));
            clp.rightMargin = Ui.dp(this, 8);
            clp.topMargin = Ui.dp(this, 6);
            chip.setOnClickListener(v -> {
                cfg.color = col;
                cfg.rgb = false;
                updatingUi = true;
                swRgb.setChecked(false);
                updatingUi = false;
                esp.invalidate();
                sendCfg("rgbMode", false);
                sendCfg("colorHex", String.format(Locale.US, "#%06X", col & 0xFFFFFF));
            });
            chips.addView(chip, clp);
        }
        panelContent.addView(chips);

        addSection(panelContent, "Công cụ");
        swFly = makeSwitch(cfg.fly, (b, on) -> {
            cfg.fly = on;
            esp.invalidate();
            cmd("fly", "enable", on, "speed", (double) cfg.flySpeed);
        });
        addRow(panelContent, "Bay (fly)", swFly);

        speedLabel = Ui.text(this, speedText(), 11f, Ui.MUTED, false);
        panelContent.addView(speedLabel);
        speedBar = new SeekBar(this);
        speedBar.setMax(100);
        speedBar.setProgress(Math.max(1, Math.round(cfg.flySpeed * 10f)));
        speedBar.setProgressTintList(ColorStateList.valueOf(Ui.ACCENT));
        speedBar.setThumbTintList(ColorStateList.valueOf(Ui.ACCENT));
        speedBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (!fromUser) return;
                cfg.flySpeed = Math.max(1, p) / 10f;
                speedLabel.setText(speedText());
                esp.invalidate();
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) { }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                cmd("fly_speed", "speed", (double) cfg.flySpeed);
            }
        });
        panelContent.addView(speedBar);

        swAim = makeSwitch(cfg.aim, (b, on) -> { cfg.aim = on; esp.invalidate(); cmd("aim", "enable", on); });
        addRow(panelContent, "Aim", swAim);
        swPin = makeSwitch(cfg.headPin, (b, on) -> { cfg.headPin = on; cmd("pin", "enable", on); });
        addRow(panelContent, "Khóa vị trí (pin)", swPin);

        TextView tp = makeButton("Teleport tới trước", 0xFF2A3142, 0xFF3A4660);
        tp.setOnClickListener(v -> cmd("tp"));
        LinearLayout.LayoutParams tpLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        tpLp.topMargin = Ui.dp(this, 12);
        panelContent.addView(tp, tpLp);

        TextView close = makeButton("Đóng overlay", Ui.ACCENT, Ui.ACCENT2);
        close.setOnClickListener(v -> stopSelf());
        LinearLayout.LayoutParams clLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        clLp.topMargin = Ui.dp(this, 8);
        panelContent.addView(close, clLp);

        panelScroll = new ScrollView(this);
        panelScroll.setBackground(Ui.rounded(this, Ui.CARD_ALPHA, 16, Ui.STROKE, 1));
        panelScroll.setVerticalScrollBarEnabled(false);
        panelScroll.addView(panelContent);
        panelScroll.setVisibility(View.GONE);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
                Ui.dp(this, 250), LinearLayout.LayoutParams.WRAP_CONTENT);
        plp.topMargin = Ui.dp(this, 6);
        menuRoot.addView(panelScroll, plp);

        menuLp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        menuLp.gravity = Gravity.TOP | Gravity.START;
        menuLp.x = Ui.dp(this, 16);
        menuLp.y = Ui.dp(this, 80);

        bubble.setOnTouchListener(new DragListener());
    }

    private String speedText() {
        return String.format(Locale.US, "Tốc độ bay: x%.1f", cfg.flySpeed);
    }

    private void syncUi() {
        updatingUi = true;
        if (swFly != null) swFly.setChecked(cfg.fly);
        if (swAim != null) swAim.setChecked(cfg.aim);
        if (swPin != null) swPin.setChecked(cfg.headPin);
        if (speedBar != null) speedBar.setProgress(Math.max(1, Math.round(cfg.flySpeed * 10f)));
        if (speedLabel != null) speedLabel.setText(speedText());
        updatingUi = false;
        if (esp != null) esp.invalidate();
    }

    private void togglePanel() {
        panelOpen = !panelOpen;
        if (panelOpen) {
            int maxH = (int) (getResources().getDisplayMetrics().heightPixels * 0.7f);
            panelContent.measure(
                    View.MeasureSpec.makeMeasureSpec(Ui.dp(this, 250), View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
            int want = panelContent.getMeasuredHeight();
            panelScroll.getLayoutParams().height = Math.min(want, maxH);
            panelScroll.setVisibility(View.VISIBLE);
            panelScroll.requestLayout();
        } else {
            panelScroll.setVisibility(View.GONE);
        }
        try {
            wm.updateViewLayout(menuRoot, menuLp);
        } catch (Exception ignored) {
        }
    }

    private class DragListener implements View.OnTouchListener {
        private int startX, startY;
        private float touchX, touchY;
        private boolean moved;

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    startX = menuLp.x;
                    startY = menuLp.y;
                    touchX = e.getRawX();
                    touchY = e.getRawY();
                    moved = false;
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - touchX;
                    float dy = e.getRawY() - touchY;
                    if (Math.abs(dx) > Ui.dp(OverlayService.this, 4) || Math.abs(dy) > Ui.dp(OverlayService.this, 4)) {
                        moved = true;
                    }
                    if (moved) {
                        menuLp.x = Math.max(0, startX + (int) dx);
                        menuLp.y = Math.max(0, startY + (int) dy);
                        try {
                            wm.updateViewLayout(menuRoot, menuLp);
                        } catch (Exception ignored) {
                        }
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP:
                    if (!moved) togglePanel();
                    return true;
                default:
                    return false;
            }
        }
    }
}

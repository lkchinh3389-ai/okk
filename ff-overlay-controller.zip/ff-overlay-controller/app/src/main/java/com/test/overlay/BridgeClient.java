package com.test.overlay;

import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Client TCP noi toi Frida script (server o 127.0.0.1:27111). Tu dong ket noi lai. */
public class BridgeClient {
    public interface Listener {
        void onConnection(boolean connected);
        void onFrame(EspConfig remoteCfg, List<EspOverlayView.EntityBox> entities);
    }

    public static volatile boolean connected = false;

    private final String host;
    private final int port;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService writer = Executors.newSingleThreadExecutor();

    private volatile boolean running = false;
    private volatile Socket socket;
    private volatile OutputStream out;
    private Thread thread;

    public BridgeClient(String host, int port, Listener listener) {
        this.host = host;
        this.port = port;
        this.listener = listener;
    }

    public void start() {
        if (running) return;
        running = true;
        thread = new Thread(this::loop, "ff-bridge");
        thread.setDaemon(true);
        thread.start();
    }

    public void stop() {
        running = false;
        closeQuietly();
        if (thread != null) thread.interrupt();
        writer.shutdownNow();
        connected = false;
    }

    public void send(String json) {
        try {
            writer.execute(() -> {
                OutputStream o = out;
                if (o == null) return;
                try {
                    o.write((json + "\n").getBytes("UTF-8"));
                    o.flush();
                } catch (IOException ignored) {
                }
            });
        } catch (Exception ignored) {
        }
    }

    private void closeQuietly() {
        Socket s = socket;
        socket = null;
        out = null;
        if (s != null) {
            try { s.close(); } catch (IOException ignored) { }
        }
    }

    private void setConnected(boolean c) {
        connected = c;
        main.post(() -> listener.onConnection(c));
    }

    private void loop() {
        while (running) {
            try {
                Socket s = new Socket();
                s.connect(new InetSocketAddress(host, port), 1500);
                s.setTcpNoDelay(true);
                socket = s;
                out = s.getOutputStream();
                setConnected(true);

                BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream(), "UTF-8"));
                String line;
                while (running && (line = r.readLine()) != null) {
                    parse(line);
                }
            } catch (Exception ignored) {
            } finally {
                boolean was = connected;
                closeQuietly();
                if (was) setConnected(false);
            }
            if (!running) break;
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                break;
            }
        }
    }

    private void parse(String line) {
        try {
            JSONObject root = new JSONObject(line);
            EspConfig rc = null;
            JSONObject c = root.optJSONObject("cfg");
            if (c != null) {
                rc = new EspConfig();
                rc.headPin = c.optBoolean("headPin", false);
                rc.aim = c.optBoolean("aimEnabled", false);
                rc.fly = c.optBoolean("flyEnabled", false);
                rc.flySpeed = (float) c.optDouble("flySpeed", 1.5);
                rc.box = c.optBoolean("espBox", true);
                rc.line = c.optBoolean("espLine", true);
                rc.dist = c.optBoolean("espDist", true);
                rc.hp = c.optBoolean("espHp", true);
                rc.name = c.optBoolean("espName", true);
                rc.rgb = c.optBoolean("rgbMode", true);
                try {
                    rc.color = Color.parseColor(c.optString("colorHex", "#FF3B30"));
                } catch (IllegalArgumentException ignored) {
                }
            }

            List<EspOverlayView.EntityBox> list = new ArrayList<>();
            JSONArray arr = root.optJSONArray("entities");
            if (arr != null) {
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.optJSONObject(i);
                    if (o == null) continue;
                    EspOverlayView.EntityBox b = new EspOverlayView.EntityBox();
                    b.name = o.optString("name", "?");
                    b.enemy = o.optBoolean("enemy", true);
                    b.hp = (float) o.optDouble("hp", 0);
                    b.maxHp = (float) o.optDouble("maxHp", 200);
                    b.dist = (float) o.optDouble("dist", 0);
                    b.nx = (float) o.optDouble("nx", 0.5);
                    b.ny = (float) o.optDouble("ny", 0.5);
                    b.headNx = (float) o.optDouble("headNx", b.nx);
                    b.headNy = (float) o.optDouble("headNy", b.ny);
                    b.boxW = (float) o.optDouble("boxW", 0);
                    b.boxH = (float) o.optDouble("boxH", 0);
                    list.add(b);
                }
            }

            final EspConfig fRc = rc;
            main.post(() -> listener.onFrame(fRc, list));
        } catch (Exception ignored) {
        }
    }
}

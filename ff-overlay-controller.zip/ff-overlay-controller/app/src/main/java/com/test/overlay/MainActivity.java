package com.test.overlay;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            refresh();
            handler.postDelayed(this, 500);
        }
    };

    private TextView valOverlay, valGame, btnMain, btnPerm;
    private View dotOverlay, dotGame;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        if (Build.VERSION.SDK_INT >= 33
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(poll);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(poll);
        super.onPause();
    }

    private LinearLayout statusRow(String label, boolean first) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        View dot = new View(this);
        dot.setBackground(Ui.circle(Ui.BAD));
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(Ui.dp(this, 10), Ui.dp(this, 10));
        dlp.rightMargin = Ui.dp(this, 12);
        row.addView(dot, dlp);
        row.addView(Ui.text(this, label, 14f, Ui.TEXT, false),
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView val = Ui.text(this, "", 13f, Ui.MUTED, false);
        row.addView(val);
        if (first) {
            dotOverlay = dot;
            valOverlay = val;
        } else {
            dotGame = dot;
            valGame = val;
        }
        return row;
    }

    private TextView button(String label, int from, int to) {
        TextView b = Ui.text(this, label, 15f, 0xFFFFFFFF, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(Ui.gradient(this, from, to, 14));
        int p = Ui.dp(this, 15);
        b.setPadding(p, p, p, p);
        return b;
    }

    private void buildUi() {
        int screenW = getResources().getDisplayMetrics().widthPixels;
        int pad = Ui.dp(this, 20);
        int contentW = Math.min(screenW - pad * 2, Ui.dp(this, 440));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Ui.BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(pad, pad * 2, pad, pad);
        scroll.addView(root, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));

        TextView logo = Ui.text(this, "◎", 30f, 0xFFFFFFFF, true);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(Ui.gradient(this, Ui.ACCENT, Ui.ACCENT2, 22));
        int ls = Ui.dp(this, 68);
        root.addView(logo, new LinearLayout.LayoutParams(ls, ls));

        TextView title = Ui.text(this, "FF Test Overlay", 24f, Ui.TEXT, true);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(contentW, LinearLayout.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = Ui.dp(this, 16);
        root.addView(title, tlp);

        TextView sub = Ui.text(this, "Overlay ESP + bảng điều khiển cho server riêng\nFree Fire 1.70.0 (môi trường test)", 13f, Ui.MUTED, false);
        sub.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(contentW, LinearLayout.LayoutParams.WRAP_CONTENT);
        slp.topMargin = Ui.dp(this, 6);
        root.addView(sub, slp);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(Ui.rounded(this, Ui.CARD, 18, Ui.STROKE, 1));
        int cp = Ui.dp(this, 18);
        card.setPadding(cp, cp, cp, cp);
        card.addView(statusRow("Overlay", true));
        LinearLayout r2 = statusRow("Kết nối game", false);
        LinearLayout.LayoutParams r2lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        r2lp.topMargin = Ui.dp(this, 14);
        card.addView(r2, r2lp);
        TextView port = Ui.text(this, "Cổng bridge: 127.0.0.1:" + OverlayService.PORT, 12f, Ui.MUTED, false);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        plp.topMargin = Ui.dp(this, 14);
        card.addView(port, plp);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(contentW, LinearLayout.LayoutParams.WRAP_CONTENT);
        clp.topMargin = Ui.dp(this, 26);
        root.addView(card, clp);

        btnPerm = button("Cấp quyền hiển thị trên ứng dụng khác", 0xFF2A3142, 0xFF3A4660);
        btnPerm.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()))));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(contentW, LinearLayout.LayoutParams.WRAP_CONTENT);
        blp.topMargin = Ui.dp(this, 18);
        root.addView(btnPerm, blp);

        btnMain = button("Bật overlay", Ui.ACCENT, Ui.ACCENT2);
        btnMain.setOnClickListener(v -> toggleOverlay());
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(contentW, LinearLayout.LayoutParams.WRAP_CONTENT);
        mlp.topMargin = Ui.dp(this, 12);
        root.addView(btnMain, mlp);

        TextView hint = Ui.text(this,
                "1. Cấp quyền overlay, bấm “Bật overlay”.\n"
                        + "2. Mở game đã gắn Frida Gadget + ff_test_hook.js.\n"
                        + "3. Chạm biểu tượng ◎ nổi trên màn hình để mở bảng điều khiển (kéo để di chuyển).",
                12f, Ui.MUTED, false);
        hint.setLineSpacing(0f, 1.2f);
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(contentW, LinearLayout.LayoutParams.WRAP_CONTENT);
        hlp.topMargin = Ui.dp(this, 22);
        root.addView(hint, hlp);

        setContentView(scroll);
    }

    private void toggleOverlay() {
        if (OverlayService.running) {
            stopService(new Intent(this, OverlayService.class));
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            btnPerm.performClick();
            return;
        }
        Intent i = new Intent(this, OverlayService.class).setAction(OverlayService.ACTION_START);
        ContextCompat.startForegroundService(this, i);
    }

    private void refresh() {
        boolean perm = Settings.canDrawOverlays(this);
        boolean on = OverlayService.running;
        boolean game = BridgeClient.connected;

        btnPerm.setVisibility(perm ? View.GONE : View.VISIBLE);
        btnMain.setText(on ? "Tắt overlay" : "Bật overlay");
        btnMain.setBackground(on
                ? Ui.gradient(this, 0xFF2A3142, 0xFF3A4660, 14)
                : Ui.gradient(this, Ui.ACCENT, Ui.ACCENT2, 14));

        valOverlay.setText(on ? "Đang chạy" : (perm ? "Đã dừng" : "Thiếu quyền"));
        dotOverlay.setBackground(Ui.circle(on ? Ui.OK : Ui.BAD));
        valGame.setText(game ? "Đã kết nối" : "Đang chờ");
        dotGame.setBackground(Ui.circle(game ? Ui.OK : Ui.BAD));
    }
}
